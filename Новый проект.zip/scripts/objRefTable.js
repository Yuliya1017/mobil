const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.Sprite
	];
};
self.C3_JsPropNameTable = [
	{Спрайт: 0}
];

self.InstanceType = {
	Спрайт: class extends self.ISpriteInstance {}
}